<?php
namespace App\Models;

use CodeIgniter\Model;

class Home_model extends Model{
    protected $table = 'user';
    protected $primaryKey = 'user_id';

    public function ambil_user(){
        return $this->findAll();
    }
}
