<?php

namespace App\Models;

use CodeIgniter\Model;

class Register_model extends Model
{
    protected $table = 'user';
    protected $primaryKey = 'user_id';
    protected $allowedFields = ['user_id', 'username', 'email', 'password', 'status'];


    public function cek_email($email){
        return $this->where('email',$email)->first();//select * from user where email = $email
    }

    public function auto_id(){
        return $this->orderBy('user_id', 'desc')
				   ->limit(1)
				   ->select('user_id')
                   ->find();
    }

    public function cek_id($id){
        $data = $this->where('user_id',$id)->first();
        if(empty($data)){
            return true;
        }
        else{
            return false;
        }
    }
}
