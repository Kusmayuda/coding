<?php
namespace App\Controllers;

class Layout extends BaseController{
	
	public function index(){
		$data = [
			'judul' => 'Dashboard'
		];
		return view('layout/dashboard1', $data);
	}
}