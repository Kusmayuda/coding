<?php

namespace App\Controllers;

use App\Models\Register_model;

class Register extends BaseController
{
	protected $registerModel;

	public function __construct()
	{
		$this->registerModel = new Register_model();
	}

	public function index()
	{
		$data = [
			'judul' => 'Registrasi',
			'validation' => \Config\Services::validation()
		];
		return view('home/registrasi', $data);
	}

	public function userRegisForm()
	{
		if (!$this->validate([
			'username' => [
				'rules' => 'required',
				'errors' => [
					'required' => '*Username wajib diisi.'
				]
			],
			'email' => [
				'rules' => 'required|valid_email|is_unique[user.email]',
				'errors' => [
					'required' => '*email wajib diisi.',
					'valid_email' => '*email tidak valid.',
					'is_unique' => '*email sudah terdaftar'
				]
			],
			'password' => [
				'rules' => 'required|min_length[6]',
				'errors' => [
					'required' => '*password wajib diisi.',
					'min_length' => '*password minimal 6 karakter'
				]
			],
		])) {
			$validation = \Config\Services::validation();
			return redirect()->to('/register')->withInput()->with('validation', $validation);
		}
		$username = $_POST['username'];
		$email = $_POST['email'];
		$email = strtolower($email);
		$pass = $_POST['password'];
		$status = $_POST['status'];

		if (empty($this->registerModel->cek_email($email))) {
			$data = [
				'username' => $username,
				'email' => $email,
				'password' => md5($pass),
				'status' => $status
			];

			while (true) {
				$id_user = rand(10000, 99999);
				$data['user_id'] = $id_user;
				if ($this->registerModel->cek_id($id_user)) {
					$this->registerModel->insert($data);
					session()->setFlashdata('pesan', 'Registrasi berhasil.');
					return redirect()->to('/home');
				}
			}
		}
	}
}
