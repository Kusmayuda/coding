<?php

namespace App\Controllers;

use App\Models\Home_model;

class Home extends BaseController
{
	protected $homeModel;

	public function __construct()
	{
		$this->homeModel = new Home_model();
	}

	public function index()
	{
		$data = [
			'judul' => 'Home',
			'all' => $this->homeModel->ambil_user(),
			'validation' => \Config\Services::validation()
		];
		return view('home/login', $data);
	}

	public function dashboard()
	{
		$data = [
			'judul' => 'Dashboard'
		];
		return view('layout/dashboard1', $data);
	}

	public function homeLogin()
	{
		if (!$this->validate([
			'email' => [
				'rules' => 'required|valid_email',
				'errors' => [
					'required' => '*email wajib diisi.',
					'valid_email' => '*email tidak valid.'
				]
			],
			'pass' => [
				'rules' => 'required',
				'errors' => [
					'required' => '*password wajib diisi.'
				]
			],
		])) {
			$validation = \Config\Services::validation();
			return redirect()->to('/home')->withInput()->with('validation', $validation);
		}
		$id = $_POST['email'];
		$id = strtolower($id);
		$password = md5($_POST['pass']);

		$data = [
			'judul' => 'Login',
			'SemuaData' => $this->homeModel->ambil_user()
		];

		foreach ($data['SemuaData'] as $nilai) {
			if ($id == $nilai['email']  && $password == $nilai['password']) {
				return redirect()->to('/home/dashboard');
			}
		}

		session()->setFlashdata('gagalLogin', 'Password dan email tidak cocok.');
		return redirect()->to('/home')->withInput();
	}
}
