<!DOCTYPE html>
<html>

<head>
    <title>Registrasi</title>
    <!-- bootstrap css -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <!-- boostrap theme -->
    <link rel="stylesheet" type="text/css" href="http://localhost/appstarter/public/assets/bootstrap/css/bootstrap-theme.min.css">
    <!-- custom css -->
    <link rel="stylesheet" type="text/css" href="http://localhost/appstarter/public/custom/css/custom.css">
    <!-- jquery -->
    <script type="text/javascript" src="http://localhost/appstarter/public/assets/jquery/jquery.min.js"></script>
    <!-- boostrap js -->
    <script type="text/javascript" src="http://localhost/appstarter/public/assets/bootstrap/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="col-md-6 col-md-offset-3 vertical-off-4">
        <div class="panel panel-default login-form">
            <div class="panel-body">
                <form action="<?= base_url('/'); ?>/Register/userRegisForm" method="post" id="loginForm">
                    <fieldset>
                        <legend>
                            Registrasi
                        </legend>
                        <div class="form-group">
                            <input type="text" class="form-control <?= ($validation->hasError('username')) ? 'is-invalid' : ''; ?>" id="username" name="username" placeholder="Username" value="<?= old('username'); ?>" autofocus>
                            <div class="invalid-feedback">
                                <?= $validation->getError('username'); ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control <?= ($validation->hasError('email')) ? 'is-invalid' : ''; ?>" id="email" name="email" placeholder="Email" value="<?= old('email'); ?>">
                            <div class="invalid-feedback">
                                <?= $validation->getError('email'); ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <input type="password" class="form-control <?= ($validation->hasError('password')) ? 'is-invalid' : ''; ?>" id="password" name="password" placeholder="Password" value="<?= old('password'); ?>">
                            <div class="invalid-feedback">
                                <?= $validation->getError('password'); ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <select class="form-control" id="status" name="status" placeholder="Status">
                                <option value="1">Guru</option>
                                <option value="0">Siswa</option>
                            </select>
                        </div>
                        <button type="submit" class="col-md-12 btn btn-primary login-button">Submit</button>

                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</body>

</html>