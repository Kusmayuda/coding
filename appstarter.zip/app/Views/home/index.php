<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> Home</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?= base_url('/'); ?>/plugins/fontawesome-free/css/all.min.css" />
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" />
    <!-- Tempusdominus Bbootstrap 4 -->
    <link rel="stylesheet" href="<?= base_url('/'); ?>/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css" />
    <!-- iCheck -->
    <link rel="stylesheet" href="<?= base_url('/'); ?>/plugins/icheck-bootstrap/icheck-bootstrap.min.css" />
    <!-- JQVMap -->
    <link rel="stylesheet" href="<?= base_url('/'); ?>/plugins/jqvmap/jqvmap.min.css" />
    <!-- Theme style -->
    <link rel="stylesheet" href="<?= base_url('/'); ?>/dist/css/adminlte.min.css" />
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="<?= base_url('/'); ?>/plugins/overlayScrollbars/css/OverlayScrollbars.min.css" />
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?= base_url('/'); ?>/plugins/daterangepicker/daterangepicker.css" />
    <!-- summernote -->
    <link rel="stylesheet" href="<?= base_url('/'); ?>/plugins/summernote/summernote-bs4.css" />
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet" />
</head>

<body style="background-image: url('../public/img/bg_login.png');">

  <div>

    <center>
      <br><br><br><br><br><br><br><br><br>
      <a>
        <h4 style="color:white;">LOGIN</h4>
      </a>
    </center>
    <center>
      <form action="<?= base_url('/'); ?>/Home/homeLogin" method="post">
        <label for="uname" style="color:white;">Email</label><br>
        <input type="text" id="uname" name="uname" value="" placeholder="Email"><br>
        <label for="pass" style="color:white;">Password:</label><br>
        <input type="password" id="pass" name="pass" value="" placeholder="Password"><br><br>
        <input type="submit" class="btn btn-primary" value="LOGIN">
      </form>
    </center>
    <center>
      <div class="col-lg-6">
        <?php //Flasher::flash(); 
        ?>
      </div>
    </center>


  </div>


  <center>
    <div class="col-lg-6">
      <button type="button" class="btn btn-primary mt-2 mb-2" data-toggle="modal" data-target="#formModalRegister">
        REGISTER
      </button>
    </div>
  </center>

  <!-- Modal -->
  <div class="modal fade" id="formModalRegister" tabindex="-1" role="dialog" aria-labelledby="judulModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="formModalLabel">Register</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?= base_url('/'); ?>/Register/userRegisForm" method="post">


            <div class="form-group">
              <label for="nama">Username</label>
              <input type="text" class="form-control" id="uname" name="uname">
            </div>
            <div class="form-group">
              <label for="email">Email</label>
              <input type="email" class="form-control" id="email" name="email">
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" class="form-control" id="password" name="password">
              <label>
                <p style="color:red;font-size:10px;">*MIN 6 CHARACTER</p>
              </label>
            </div>
            <div class="form-group">
              <label for="jurusan">Status</label>
              <select class="form-control" id="status" name="status">
                <option value="1">Guru</option>
                <option value="0">Siswa</option>
              </select>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js" integrity="sha256-xNzN2a4ltkB44Mc/Jz3pT4iU1cmeR0FkXs4pru/JxaQ=" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  <script src="<?= base_url('/'); ?>/js/script.js"></script>

</body>

</html>