<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>About Test</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta facilis quas nihil id neque, exercitationem corrupti aliquid cum, dolore ratione vero, quia quam modi reiciendis minima accusantium ab odit quaerat.</p>
        </div>
        
    </div>
    <?php foreach($all as $some) : ?>
        <ul>
            <li><?= $some['user_id']; ?></li>
            <li><?= $some['username']; ?></li>
            <li><?= $some['email']; ?></li>
            <li><?= $some['password']; ?></li>
            <li><?= $some['status']; ?></li>
        </ul>
    <?php endforeach; ?>
</div>
<?= $this->endSection(); ?>