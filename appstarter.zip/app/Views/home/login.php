<!DOCTYPE html>
<html>

<head>
    <title><?= $judul; ?></title>
    <!-- bootstrap css -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <!-- boostrap theme -->
    <link rel="stylesheet" type="text/css" href="http://localhost/appstarter/public/assets/bootstrap/css/bootstrap-theme.min.css">
    <!-- custom css -->
    <link rel="stylesheet" type="text/css" href="http://localhost/appstarter/public/custom/css/custom.css">
    <!-- jquery -->
    <script type="text/javascript" src="http://localhost/appstarter/public/assets/jquery/jquery.min.js"></script>
    <!-- boostrap js -->
    <script type="text/javascript" src="http://localhost/appstarter/public/assets/bootstrap/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="col-md-6 col-md-offset-3 vertical-off-4">
        <div class="panel panel-default login-form">
            <div class="panel-body">
                <form action="<?= base_url('/'); ?>/Home/homeLogin" method="post" id="loginForm">
                    <fieldset>
                        <legend>
                            Login
                        </legend>

                        <?php if (session()->getFlashdata('pesan')) : ?>
                            <div class="alert alert-success" role="alert">
                                <?= session()->getFlashdata('pesan'); ?>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                        <?php if (session()->getFlashdata('gagalLogin')) : ?>
                            <div class="alert alert-danger" role="alert">
                                <?= session()->getFlashdata('gagalLogin'); ?>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                        <div id="message"></div>

                        <div class="form-group">

                            <input type="text" class="form-control <?= ($validation->hasError('email')) ? 'is-invalid' : ''; ?>" id="email" name="email" placeholder="Email" value="<?= old('email'); ?>" autofocus>
                            <div class="invalid-feedback">
                                <?= $validation->getError('email'); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control <?= ($validation->hasError('pass')) ? 'is-invalid' : ''; ?>" id="pass" name="pass" placeholder="Password" value="<?= old('pass'); ?>">
                            <div class="invalid-feedback">
                                <?= $validation->getError('pass'); ?>
                            </div>
                        </div>

                        <button type="submit" class="col-md-12 btn btn-primary login-button">Login</button>
                        <div>
                            <a href="<?= base_url('/'); ?>/register" class="col-md-12 btn btn-primary login-button" style="color:white; margin-top: 5px;">Register</a>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</body>

</html>